import { Component } from '@angular/core';

@Component({
  selector: 'app-child',
  standalone: true,
  template:`
  <h2>Child Component</h2>
  `,
})
export class ChildComponent {
  title = 'step2-components';
}
