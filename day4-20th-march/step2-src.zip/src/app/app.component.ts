import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  template:`
  <h1>Components</h1>
  <hr>
  <app-child></app-child>
  `,
})
export class AppComponent {
  title = 'step2-components';
}
