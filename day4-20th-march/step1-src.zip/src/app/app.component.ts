import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  styles : `
    .box{
      width: 200px;
      height: 50px;
      background-color: darkslategray;
      color: aliceblue;
      font-family: sans-serif;
      text-align: center;
      margin: 10px auto;
      line-height:50px
  }`,
  template : `
  <h1> {{ title }}</h1>
  <h1> {{ 5 + 6 }} </h1>
  <h2 [innerHTML]="title"></h2>
  <h3 [innerText]="title"></h3>
  <h4 [textContent]="title"></h4>
  <h3 bind-textContent="title"></h3>
  <h4>Power is : {{ power }}</h4>
  <input type="range" [value]="power">
  <br>
  <br>
  <button [disabled]="show">Click Me</button>
  <div [class]="selectedStyle">I am a Box</div>
  <div [class]="selectedStyle">{{ saymessage() }}</div>
  <button (click)="sayAlert()">Click Me to Show Alert</button>
  <input type="number" #pow [value]="power" (change)="setPower(pow.value)">
  <input type="range" #pow1 [value]="power" (input)="setPower(pow1.value)">
  `,
})
export class AppComponent {
  title:string = "Welcome to your life";
  power:any = 1;
  show:boolean = true;
  selectedStyle = "box";
  saymessage(){ return "Hello Miscot Mumbai"; }
  sayAlert(){ alert("did you click me"); }
  setPower(npower:any){ this.power = npower }
}
