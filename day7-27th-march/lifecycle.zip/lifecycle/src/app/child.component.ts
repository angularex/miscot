import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <h2>Child Component</h2>
    <h3>Power is : {{ power }}</h3>
  `,
  styles: [
  ]
})
export class ChildComponent implements OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewChecked, AfterViewInit, OnDestroy {
// properties
@Input()power = 0;

// constructor
  constructor(){
    console.log("ChildComponent's constructor was called")
  }
// methods events
  ngOnInit(){
    console.log("ChildComponent's ngOnInit was called")
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ChildComponent's ngOnChanges was called", changes);
    /* 
    if(changes['power'].currentValue >= 15){
      this.power = 9;
      console.log(changes['power'].currentValue)
    } 
    */
  }
  ngDoCheck(): void {
    console.log("ChildComponent's ngDoCheck was called");
  }
  ngAfterContentChecked(): void {
    console.log("ChildComponent's ngAfterContentChecked was called")
  }
  ngAfterContentInit(): void {
    console.log("ChildComponent's ngAfterContentInit was called")
  }
  ngAfterViewChecked(): void {
    console.log("ChildComponent's ngAfterViewChecked was called")
  }
  ngAfterViewInit(): void {
    console.log("ChildComponent's ngAfterViewInit was called")
  }
  ngOnDestroy(): void {
    console.log("ChildComponent's ngOnDestroy was called")
  }
}
