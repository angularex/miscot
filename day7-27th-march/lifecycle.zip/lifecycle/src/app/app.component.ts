import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1 [innerText]="title"></h1>
    <input type="number" [(ngModel)]="appPower">
    <input [(ngModel)]="show" type="checkbox">
    <hr>
    <app-child *ngIf="show" [power]="appPower"></app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'Lifecycle of a component';
  appPower = 1;
  show = true;
  constructor(){
    console.log("AppComponent's constructor was called")
  }
  ngOnInit(){
    console.log("AppComponent's ngOnInit was called")
  }
}
