import { Component, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-header',
  template: `
  <div style="border : 1px solid grey; padding : 10px">
    <ul class="nav">
        <li class="nav-item" *ngFor="let hero of herolist">
            <a class="nav-link" href="#">{{ hero.title }}</a>
        </li>
    </ul>
  </div>
  <h2>service version is : {{ version }}</h2>
  `,
  styles: [
  ]
})
export class HeaderComponent {
  @Input()herolist:any = [];
  @Input()version = 0;
  /* 
  hs:HeroService = new HeroService();
  constructor(){
    this.herolist = this.hs.getServiceData();
    this.version = this.hs.getServiceVersion();
  } 
  */
/*   constructor(private hs:HeroService){
    this.herolist = this.hs.getServiceData();
    this.version = this.hs.getServiceVersion();
  } */
}
