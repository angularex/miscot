import { Component } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  template: `
  <div class="container">
    <h1>Data in Angular</h1>
    <app-header [herolist]="appdata?.serverdata" [version]="appversion" herolist></app-header>
    <hr>
    <app-grid [herolist]="appdata?.serverdata" [version]="appversion" herolist></app-grid>
  </div>
  `,
  styles : []
})
export class AppComponent {
  title = 'pipes';
  appdata:any;
  appversion:any = 0;
  constructor(private hs:HeroService){
    // empty
  }
  ngOnInit(){
    this.hs.getServiceData().subscribe(dbres => this.appdata = dbres );
    this.appversion = this.hs.getServiceVersion();
  }
  ngOnDestroy(): void {
   
  }

}
