import { Component, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-grid',
  template: `
  <h2>service version is : {{ version }}</h2>
  <table class="table">
  <thead class="table-dark">
    <tr>
      <th>Sl #</th>
      <th>Title</th>
      <th>Full Name</th>
      <th>Poster</th>
      <th>City</th>
      <th>Release Date</th>
      <th>Ticket Price</th>
      <th>Movies</th>
    </tr>
  </thead>
  <tbody>
    <tr *ngFor="let hero of herolist">
      <td>{{ hero.sl }}</td>
      <td>{{ hero.title | uppercase }}</td>
      <td>{{ hero.firstname+" "+hero.lastname | uppercase | lowercase | titlecase }}</td>
      <td>
        <img width="50" [src]="hero.poster" [alt]="hero.title">
      </td>
      <td>{{ hero.city }}</td>
      <td>{{ hero.releasedate | date:'dd-MMM-yyyy' }}</td>
      <td>{{ hero.ticketprice | currency:'INR':'symbol':'4.2-4' }}</td>
      <td>
         <div style="float:left; padding: 5px; border : 1px solid grey; margin : 2px" *ngFor="let movie of hero.movieslist" >
             <img width="50" [src]="movie.poster" [alt]="movie.title">     
         </div>
      </td>
    </tr>
  </tbody>
  </table>
  `,
  styles: [
  ]
})
export class GridComponent {
  @Input()herolist:any = [];
  @Input()version = 0;
  /* 
  hs:HeroService = new HeroService();
  constructor(){
    this.herolist = this.hs.getServiceData();
    this.version = this.hs.getServiceVersion();
  } 
  */
/*   constructor(private hs:HeroService){
    this.herolist = this.hs.getServiceData();
    this.version = this.hs.getServiceVersion();
  } */
}
