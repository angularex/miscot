import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
    selector : "app-child",
    /* inputs : ['pow','log','list1','list2'], */
    template : `
        <div>
            <h2>Child Component</h2>
            <h2>Power is : {{ power }}</h2>
            <input #ip1 [value]="power" (input)="power = ip1.value" type="range">
            <input [(ngModel)]="power" type="number">
            <!-- <div class="box">
                <ng-content select="button"/>
                <hr>
                <ng-content select="ul"/>
                <hr>
                <ng-content select=".second"/>
                <hr>
                <ng-content/>
            </div -->
            <div class="player">
               Power is {{ pow }}
               <br>
               Message is {{ log }}
               <br>
               <textarea cols="30" rows="2">{{ list1 }}</textarea>
               <textarea cols="30" rows="2">{{ list2 }}</textarea>
            </div>
            User Name : <input #uname [value]="username" type="text">
            Password :  <input #upass [value]="userpass" type="password">
            <button (click)="clickHandler(uname.value, upass.value)">Change Title</button>
        </div>
    `,
    styles : `
        .box{
            border : 2px solid red;
            padding : 10px;
            margin : 10px;
        }
        .player{
            border : 2px dashed blue;
            padding : 10px;
            margin : 10px;
        }
    `
})
export class ChildComp{
    power:any = 10;
    username:string = "default title";
    userpass:string = "default title";
    @Input('arg1')pow:any = 0;
    @Input('arg2')log = "default";
    @Input('arg3')list1 = ['default 1', 'default 2'];
    @Input('arg4')list2 = ['default 1', 'default 2'];
    //-------------------------------------------------
    @Output()compEvt:EventEmitter<any> = new EventEmitter();
    //-------------------------------------------------

    clickHandler(arg1:any, arg2:any){
        // alert("you clicked the button");
        this.compEvt.emit({username : arg1, password : arg2});
    }
}