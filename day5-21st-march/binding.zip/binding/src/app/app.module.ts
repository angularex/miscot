import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ChildComp } from './child.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [AppComponent, ChildComp], /* you must declare components, pipes, directives */
  imports: [BrowserModule, FormsModule], /* reusable modules that can be part of one or more projects */
  providers: [], /* list of services that are injected to all the components */
  bootstrap: [AppComponent] /* list of components that will be main components */
})
export class AppModule { }
