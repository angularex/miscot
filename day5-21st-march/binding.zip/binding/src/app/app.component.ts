import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Welcome to {{title}}!</h1>
    <h2>Power is : {{ power }}</h2>
    <input #ip1 value="{{power}}" (input)="power = ip1.value" type="range">
    <input [value]="power" (input)="changePower($event)" type="number">
    <h3 (click)="changeHeader($event)">First Heading</h3>
    <h3 (click)="changeHeader($event)">Second Heading</h3>
    <h3 (click)="changeHeader($event)">Third Heading</h3>
    <h3 (click)="changeHeader($event)">Fourth Heading</h3>
    <input type="text" [(ngModel)]="message" >
    <hr>
    <h3>Child Message : {{ childmessage }}</h3>
    <hr>
    <app-child (compEvt)="compEventHandler($event)" [arg1]="power" [arg2]="message" [arg3]="Avengers" [arg4]="JusticeLeague">
      <p> 
        First Paragraph
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus omnis eveniet sint, ipsa laudantium ullam porro, ut iure quia, aspernatur neque nulla voluptatum fugit eius! Cumque, molestias! Repellendus, cum consequatur. 
      </p>
      <p class="second"> 
        Second Paragraph
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus omnis eveniet sint, ipsa laudantium ullam porro, ut iure quia, aspernatur neque nulla voluptatum fugit eius! Cumque, molestias! Repellendus, cum consequatur. 
      </p>
      <button>Click Me</button>
      <ul>
        <li>List Item 1</li>
        <li>List Item 2</li>
        <li>List Item 3</li>
        <li>List Item 4</li>
        <li>List Item 5</li>
      </ul>
    </app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'binding';
  power:any = 5;
  childmessage:string = "default child message";
  message = "Welcome to your life";
  Avengers = ['Ironman','Hulk','Thor','Black Widow'];
  JusticeLeague = ['Batman','Superman','Wonder Women'];

  changePower(evt:any){
    alert("power is changed")
  }

  changeHeader(evt:any){
    // alert("do you want to change "+evt.target.innerText)
    evt.target.innerText = "Clicked";
  }

  compEventHandler(evt:any){
    // alert("comp event happened");
    this.childmessage = evt.username+" : "+evt.password;
  }
}
