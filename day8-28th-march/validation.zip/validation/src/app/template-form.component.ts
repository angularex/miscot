import { Component } from '@angular/core';

@Component({
  selector: 'app-template-form',
  template: `
    <h2>Template Driven Forms in Angular</h2>
    <form action="#" #myform="ngForm" method="get" name="myform" (submit)="submitHandler($event, myform)">
      <div class="mb-3">
        <label for="uname" class="form-label">Name</label>
        <input #un="ngModel" [(ngModel)]="username" required name="username" class="form-control" id="uname">
        <span *ngIf="un.touched && un.invalid" style="color : red">User Name field is required please fill your name</span>
      </div>
      <div class="mb-3">
        <label for="uemail" class="form-label">eMail</label>
        <input type="text" #um="ngModel" [(ngModel)]="usermail" pattern=".+@.+" required name="usermail" class="form-control" id="uemail">
        <span *ngIf="um.touched && um.invalid" style="color : red">User eMail field is required please fill your email id</span>
        </div>
      <div class="mb-3">
        <label for="uage" class="form-label">Age</label>
        <input type="number" #ua="ngModel" [(ngModel)]="userage" min="18" max="90" step="1" required name="userage" class="form-control" id="uage">
        <span *ngIf="ua.touched && ua.invalid" style="color : red">User Age field is required please fill your age</span>
        </div>
      <div class="mb-3">
        <button [disabled]="myform.invalid"  class="btn btn-primary">Submit Form Data</button>
      </div>
    </form>
    <hr>
    <ul>
      <li>User Name : {{ username }}</li>
      <li>User Mail : {{ usermail }}</li>
      <li>User Age : {{ userage }}</li>
    </ul>
    <ul>
      <li *ngIf="un.untouched" >User Name is Untouched</li>
      <li *ngIf="un.touched" >User Name is Touched</li>
      <li *ngIf="un.pristine" >User Name is Pristine</li>
      <li *ngIf="un.dirty" >User Name is Dirty</li>
      <li *ngIf="un.valid" >User Name is Valid</li>
      <li *ngIf="un.invalid" >User Name is InValid</li>
    </ul>
    <ul>
      <li *ngIf="um.untouched">User Mail is Untouched</li>
      <li *ngIf="um.touched">User Mail is Touched</li>
      <li *ngIf="um.pristine">User Mail is Pristine</li>
      <li *ngIf="um.dirty">User Mail is Dirty</li>
      <li *ngIf="um.valid">User Mail is Valid</li>
      <li *ngIf="um.invalid">User Mail is InValid</li>
    </ul>
    <ul>
      <li *ngIf="ua.untouched">User Age is Untouched</li>
      <li *ngIf="ua.touched">User Age is Touched</li>
      <li *ngIf="ua.pristine">User Age is Pristine</li>
      <li *ngIf="ua.dirty">User Age is Dirty</li>
      <li *ngIf="ua.valid">User Age is Valid</li>
      <li *ngIf="ua.invalid">User Age is InValid</li>
    </ul>

  `,
  styles: [`
  input.ng-touched.ng-invalid{
      border : 2px solid crimson;
  }
  input.ng-touched.ng-valid{
      border : 2px solid darkseagreen;
  }
  `]
})
export class TemplateFormComponent {
  username = "";
  usermail = "";
  userage = "";
  submitHandler(evt:any, formdata:any){
    evt.preventDefault();

    // var regex = new RegExp("^\S+@\S+\.\S+$");
    // console.log(regex.test(formdata.form.value.usermail));
    // console.log(evt);
    // console.log(formdata)
    // console.log(this.usermail)
     /* if(formdata.form.value.userage < 18){
        alert("you are too young to join us")
      }else if(formdata.form.value.userage > 80){
       alert("you are too old to join us")
     }else{
        evt.target.submit();
     } */
  }
}


/* 
.+@.+

.+@.+.\.+ 

\S+@\S+\.\S+

*/