import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <div class="container">
    <h1 bind-innerText="title"></h1>
    <hr>
    <app-template-form/>
    <hr>
    <app-reactive-form/>
    <hr>
    <app-reactive-builder-form></app-reactive-builder-form>
  </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'Form Validation';
}
